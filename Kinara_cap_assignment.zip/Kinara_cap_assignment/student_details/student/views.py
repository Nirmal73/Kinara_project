from django.shortcuts import render, HttpResponse, HttpResponseRedirect
from .models import Student, Class
from django.db.models import Q


# Create your views here.

def index(request):
    return render(request, 'index.html')


def view_all(request):
    if request.method == 'GET' and 'id' in request.GET:
        idVal = request.GET['id']
        nameVal = request.GET['name']

        studs = Student.objects.all()
        if idVal:
            studs = studs.filter(Q(id=idVal))
        if nameVal:
            studs = studs.filter(Q(first_name=nameVal) | Q(last_name=nameVal))

        context = {
            'studs': studs,
            'id' : idVal,
            'name': nameVal
        }
    else:
        studs = Student.objects.all()
        context = {
            'studs' : studs
        }
        
    return render(request, 'view_all.html', context)


def add_stu(request):
    if request.method == 'POST':
        id = int(request.POST['id'])
        first_name = request.POST['first_name']
        last_name = request.POST['last_name']
        Class= int(request.POST['Class'])
        father_name = request.POST['father_name']
        total_marks = int(request.POST['total_marks'])
        phone = int(request.POST['phone'])
        new_stud = Student(id = id, first_name = first_name, last_name = last_name, Class_id = Class, father_name = father_name, total_marks = total_marks, phone = phone)
        new_stud.save()
        return HttpResponseRedirect('/view_all')
    elif request.method == "GET":
        return render(request, 'add_stu.html')
    else:
        return HttpResponse("An Exception Occured! Student has not been added.")


def remove_stu(request, id):
    if request.method == "POST":
        pi = Student.objects.get(id = id)
        pi.delete()
        return HttpResponseRedirect('/view_all')


def filter_stu(request):
    if request.method == 'GET' and 'idVal' in request.GET:
        idVal = request.GET['idVal']
        nameVal = request.GET['nameVal']

        studs = Student.objects.all()
        studs = Student.objects.filter(id=idVal).values()
        studs = Student.objects.filter(first_name=nameVal).values()
        print(studs)
        '''if name:
            studs = studs.filter(Q(first_name__icontains=name)
                                 | Q(last_name__icontains=name))
        if id:
            studs = studs.filter(id__name=id)'''

        context = {

            'studs': studs
        }
        #print(context)
        return render(request, 'view_all.html', context)

    return render(request, 'view_all.html')
    

