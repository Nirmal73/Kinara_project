<?php

namespace Mautic\LeadBundle\Segment\Exception;

class FieldNotFoundException extends \Exception
{
}
