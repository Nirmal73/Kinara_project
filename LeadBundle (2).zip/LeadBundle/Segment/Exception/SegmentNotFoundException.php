<?php

namespace Mautic\LeadBundle\Segment\Exception;

class SegmentNotFoundException extends \Exception
{
}
