<?php

namespace Mautic\LeadBundle\Segment\Exception;

class PluginHandledFilterException extends \Exception
{
}
