<?php

namespace Mautic\LeadBundle\Segment\Exception;

/**
 * This exception is risen if functionality requested does not belong to give FilterQueryBuilder.
 */
class InvalidUseException extends SegmentQueryException
{
}
