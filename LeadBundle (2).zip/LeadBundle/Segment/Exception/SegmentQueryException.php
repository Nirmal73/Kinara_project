<?php

namespace Mautic\LeadBundle\Segment\Exception;

use Doctrine\DBAL\Query\QueryException;

/**
 * Class SegmentQueryException.
 */
class SegmentQueryException extends QueryException
{
}
