<?php

namespace Mautic\LeadBundle\Event;

class CompanyBuildSearchEvent extends LeadBuildSearchEvent
{
}
