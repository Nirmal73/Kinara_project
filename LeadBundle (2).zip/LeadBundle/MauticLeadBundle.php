<?php

namespace Mautic\LeadBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

/**
 * Class MauticLeadBundle.
 */
class MauticLeadBundle extends Bundle
{
}
