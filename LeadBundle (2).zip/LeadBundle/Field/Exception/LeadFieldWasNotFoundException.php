<?php

declare(strict_types=1);

namespace Mautic\LeadBundle\Field\Exception;

class LeadFieldWasNotFoundException extends \Exception
{
}
