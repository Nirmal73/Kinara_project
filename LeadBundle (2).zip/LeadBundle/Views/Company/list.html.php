<?php

/*
 * @copyright   2014 Mautic Contributors. All rights reserved
 * @author      Mautic
 *
 * @link        http://mautic.org
 *
 * @license     GNU/GPLv3 http://www.gnu.org/licenses/gpl-3.0.html
 */
 
 include('././app/config/local.php');
// Get the user Id of the user who logged in
$user_id = $app->getUser()->getId();
$url = $parameters['site_url'] . '/media/addons/company_field.php/?id=' . $user_id;
$cURLConnection = curl_init();
curl_setopt($cURLConnection, CURLOPT_URL, $url);
curl_setopt($cURLConnection, CURLOPT_RETURNTRANSFER, true);
$selectionList = curl_exec($cURLConnection); // getting selection list from database
curl_close($cURLConnection);


if ('index' == $tmpl) {
    $view->extend('MauticLeadBundle:Company:index.html.php');
}
?>

<?php if (count($items)): ?>
    <div class="table-responsive page-list">
        <table class="table table-hover table-striped table-bordered company-list" id="companyTable">
            <thead>
            <tr>
                <?php
                echo $view->render(
                    'MauticCoreBundle:Helper:tableheader.html.php',
                    [
                        'checkall'        => 'true',
                        'target'          => '#companyTable',
                        'routeBase'       => 'company',
                        'templateButtons' => [
                            'delete' => $permissions['lead:leads:deleteother'],
                        ],
                    ]
                );

                echo $view->render(
                    'MauticCoreBundle:Helper:tableheader.html.php',
                    [
                        'sessionVar' => 'company',
                        'text'       => 'mautic.company.name',
                        'class'      => 'col-company-name',
                        'orderBy'    => 'comp.companyname',
                    ]
                );
                echo $view->render(
                    'MauticCoreBundle:Helper:tableheader.html.php',
                    [
                        'sessionVar' => 'company',
                        'text'       => 'mautic.company.email',
                        'class'      => 'visible-md visible-lg col-company-category',
                        'orderBy'    => 'comp.companyemail',
                    ]
                );
                echo $view->render(
                    'MauticCoreBundle:Helper:tableheader.html.php',
                    [
                        'sessionVar' => 'company',
                        'text'       => 'mautic.company.website',
                        'class'      => 'visible-md visible-lg col-company-website',
                        'orderBy'    => 'comp.companywebsite',
                    ]
                );
                echo $view->render(
                    'MauticCoreBundle:Helper:tableheader.html.php',
                    [
                        'sessionVar' => 'company',
                        'text'       => 'mautic.company.score',
                        'class'      => 'visible-md visible-lg col-company-score',
                        'orderBy'    => 'comp.score',
                    ]
                );
                echo $view->render('MauticCoreBundle:Helper:tableheader.html.php',
                    [
                        'sessionVar' => 'company',
                        'text'       => 'mautic.lead.list.thead.leadcount',
                        'class'      => 'visible-md visible-lg col-leadlist-leadcount',
                    ]
                );
                echo $view->render(
                    'MauticCoreBundle:Helper:tableheader.html.php',
                    [
                        'sessionVar' => 'company',
                        'orderBy'    => 'comp.id',
                        'text'       => 'mautic.core.id',
                        'class'      => 'visible-md visible-lg col-company-id',
                    ]
                );
                if (strpos($selectionList, 'email') !== false) {
                        echo $view->render(
                            'MauticCoreBundle:Helper:tableheader.html.php',
                            [
                                'sessionVar' => 'company',
                                'text'       => 'mautic.company.email',
                                'class'      => 'visible-md visible-lg col-company-category',
                                'orderBy'    => 'comp.companyemail',
                            ]
                        );
                    }
                    if (strpos($selectionList, 'phone') !== false) {
                        echo $view->render(
                            'MauticCoreBundle:Helper:tableheader.html.php',
                            [
                                'sessionVar' => 'company',
                                'text'       => 'mautic.company.phone',
                                'class'      => 'visible-md visible-lg col-company-category',
                                'orderBy'    => 'comp.companyphone',
                            ]
                        );
                    }
                    if (strpos($selectionList, 'country') !== false) {
                        echo $view->render(
                            'MauticCoreBundle:Helper:tableheader.html.php',
                            [
                                'sessionVar' => 'company',
                                'text'       => 'mautic.company.country',
                                'class'      => 'visible-md visible-lg col-company-category',
                                'orderBy'    => 'comp.companycountry',
                            ]
                        );
                    }
                    if (strpos($selectionList, 'id') !== false) {
                        echo $view->render(
                            'MauticCoreBundle:Helper:tableheader.html.php',
                            [
                                'sessionVar' => 'company',
                                'orderBy'    => 'comp.id',
                                'text'       => 'mautic.core.id',
                                'class'      => 'visible-md visible-lg col-company-id',
                            ]
                        );
                    }
                    #added by nirmal for city
                    if (strpos($selectionList, 'city') !== false) {
                        echo $view->render(
                            'MauticCoreBundle:Helper:tableheader.html.php',
                            [
                                'sessionVar' => 'company',
                                'orderBy'    => 'comp.city',
                                'text'       => 'City',
                                'class'      => 'visible-md visible-lg col-company-id',
                            ]
                        );
                    }
                    
                    
                ?>
            </tr>
            </thead>
            <tbody>
            <?php foreach ($items as $item): ?>
                <?php $fields = $item->getFields(); ?>
                <tr>
                    <td>
                        <?php
                        echo $view->render(
                            'MauticCoreBundle:Helper:list_actions.html.php',
                            [
                                'item'            => $item,
                                'templateButtons' => [
                                    'edit'   => $permissions['lead:leads:editother'],
                                    'clone'  => $permissions['lead:leads:create'],
                                    'delete' => $permissions['lead:leads:deleteother'],
                                ],
                                'routeBase' => 'company',
                            ]
                        );
                        ?>
                    </td>
                    <td>
                        <div>
                            <?php if ($view['security']->hasEntityAccess(
                                       $permissions['lead:leads:editown'],
                                       $permissions['lead:leads:editother'],
                                       $item->getCreatedBy()
                                       )
                                   ): ?>

                            <a href="<?php echo $view['router']->url(
                                'mautic_company_action',
                                ['objectAction' => 'view', 'objectId' => $item->getId()]
                            ); ?>" data-toggle="ajax">
                                <?php if (isset($fields['core']['companyname'])) : ?>
                                    <?php echo $view->escape($fields['core']['companyname']['value']); ?>
                                <?php endif; ?>
                            </a>
                        <?php else: ?>
                            <?php if (isset($fields['core']['companyname'])) : ?>
                                <?php echo $view->escape($fields['core']['companyname']['value']); ?>
                            <?php endif; ?>
                        <?php endif; ?>
                        </div>
                    </td>
                    <td>
                        <?php if (isset($fields['core']['companyemail'])): ?>
                        <div class="text-muted mt-4">
                            <small>
                                <?php echo $view->escape($fields['core']['companyemail']['value']); ?>
                            </small>
                        </div>
                        <?php endif; ?>
                    </td>

                    <td class="visible-md visible-lg">
                        <?php if (isset($fields['core']['companywebsite'])) :?>
                        <?php echo \Mautic\CoreBundle\Helper\InputHelper::url($fields['core']['companywebsite']['value']); ?>
                        <?php endif; ?>
                    </td>
                    <td class="visible-md visible-lg">
                        <?php echo $item->getScore(); ?>
                    </td>
                    <td class="visible-md visible-lg">
                        <a class="label label-primary" href="<?php
                        echo $view['router']->path(
                            'mautic_contact_index',
                            [
                                'search' => $view['translator']->trans('mautic.lead.lead.searchcommand.company_id').':'.$item->getId(),
                            ]
                        ); ?>" data-toggle="ajax"<?php echo (0 == $leadCounts[$item->getId()]) ? 'disabled=disabled' : ''; ?>>
                            <?php echo $view['translator']->trans(
                                'mautic.lead.company.viewleads_count',
                                ['%count%' => $leadCounts[$item->getId()]]
                            ); ?>
                        </a>
                    </td>
                    <td class="visible-md visible-lg"><?php echo $item->getId(); ?></td>
                    
                    <?php if (strpos($selectionList, 'email') !== false) { ?>
                            <td>
                                <?php if (isset($fields['core']['companyemail'])) : ?>
                                    <div class="text-muted mt-4">
                                        <small>
                                            <?php echo $view->escape($fields['core']['companyemail']['value']); ?>
                                        </small>
                                    </div>
                                <?php endif; ?>
                            </td>
                        <?php } ?>
                        <?php if (strpos($selectionList, 'phone') !== false) { ?>
                            <td class="visible-md visible-lg">
                                <?php echo $item->getPhone(); ?>
                            </td>
                        <?php } ?>
                        <?php if (strpos($selectionList, 'country') !== false) { ?>
                            <td class="visible-md visible-lg">
                                <?php echo $item->getCountry(); ?>
                            </td>
                        <?php } ?>
                        
                        <!--added by nirmal for city-->
                        
                        <?php if (strpos($selectionList, 'city') !== false) { ?>
                            <td class="visible-md visible-lg">
                                <?php echo $item->getCity(); ?>
                            </td>
                        <?php } ?>
                    
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <div class="panel-footer">
        <?php echo $view->render(
            'MauticCoreBundle:Helper:pagination.html.php',
            [
                'totalItems' => $totalItems,
                'page'       => $page,
                'limit'      => $limit,
                'menuLinkId' => 'mautic_company_index',
                'baseUrl'    => $view['router']->url('mautic_company_index'),
                'sessionVar' => 'company',
            ]
        ); ?>
    </div>
<?php else: ?>
     <script>
        jQuery('#ms').css('opacity', 0);
    </script>
    <?php echo $view->render(
        'MauticCoreBundle:Helper:noresults.html.php',
        ['tip' => 'mautic.company.action.noresults.tip']
    ); ?>
<?php endif; ?>
