<?php

/*
 * @copyright   2014 Mautic Contributors. All rights reserved
 * @author      Mautic
 *
 * @link        http://mautic.org
 *
 * @license     GNU/GPLv3 http://www.gnu.org/licenses/gpl-3.0.html
 */
 
include('././app/config/local.php');
// Get the user Id of the user who logged in
$user_id = $app->getUser()->getId();
$url = $parameters['site_url'] . '/media/addons/company_field.php?id=' . $user_id;
$cURLConnection = curl_init();
curl_setopt($cURLConnection, CURLOPT_URL, $url);
curl_setopt($cURLConnection, CURLOPT_RETURNTRANSFER, true);
$selectionList = curl_exec($cURLConnection); // getting selection list from database
curl_close($cURLConnection);


$view->extend('MauticCoreBundle:Default:content.html.php');
$view['slots']->set('mauticContent', 'company');
$view['slots']->set('headerTitle', $view['translator']->trans('mautic.companies.menu.root'));

$pageButtons = [];
if ($permissions['lead:leads:create']) {
    $pageButtons[] = [
        'attr' => [
            'href' => $view['router']->path('mautic_import_action', ['object' => 'companies', 'objectAction' => 'new']),
        ],
        'iconClass' => 'fa fa-upload',
        'btnText'   => 'mautic.lead.lead.import',
    ];

    $pageButtons[] = [
        'attr' => [
            'href' => $view['router']->path('mautic_import_index', ['object' => 'companies']),
        ],
        'iconClass' => 'fa fa-history',
        'btnText'   => 'mautic.lead.lead.import.index',
    ];
}

$view['slots']->set(
    'actions',
    $view->render(
        'MauticCoreBundle:Helper:page_actions.html.php',
        [
            'templateButtons' => [
                'new' => $permissions['lead:leads:create'],
            ],
            'routeBase'     => 'company',
            'customButtons' => $pageButtons,
        ]
    )
);
?>
<!--Added by Nirmal for company columns-->
    <div id="ms" class="multiselect visible-md visible-lg" style="float:right; padding-bottom:1%;">
        <div class="selectBox" onclick="showCheckboxes()">
            <select>
                <option>Select Columns</option>
            </select>
            <div class="overSelect"></div>
        </div>
        <div id="checkboxes">
            <label for="country">
                <input type="checkbox" id="country" value="country" onchange="check()"> Country</label>
            <label for="city">
                <input type="checkbox" id="city" value="city" onchange="check()"> City</label>
            
                <input type="checkbox" id="phone" value="phone" onchange="check()"> Phone</label>
            <span style="color: #2196F3; padding-top: 3px; padding-bottom: 3px;font-size: 9.9px;background-color: #f9f9f9;">(To add custom fields contact Support)</span>
        </div>
    </div>

<div class="panel panel-default bdr-t-wdh-0 mb-0">
    <?php echo $view->render(
        'MauticCoreBundle:Helper:list_toolbar.html.php',
        [
            'searchValue' => $searchValue,
            'searchHelp'  => 'mautic.core.help.searchcommands',
            'action'      => $currentRoute,
            'companyfilters'=>true,
        ]
    ); ?>
    
    
    <div class="page-list">
        <?php $view['slots']->output('_content'); ?>
    </div>
</div>

<script>
    url = '<?php echo $url ?>';
	jQuery.get(url, {},
        function(data, status) {
            if (data.length > 0) {
                var res = data.split(',')
                jQuery.each(res, function(key, value) {
                    jQuery('#' + value.trim()).prop("checked", "true");
                })
            }
        });
    var expanded = false;
    function showCheckboxes() {
        var checkboxes = document.getElementById("checkboxes");
        if (!expanded) {
            checkboxes.style.display = "block";
            expanded = true;
        } else {
            checkboxes.style.display = "none";
            expanded = false;
        }
    }
    function check() {
        selection = [];
        if (jQuery('#email').prop("checked") == true) {
            selection.push("email");
        }
        if (jQuery('#phone').prop("checked") == true) {
            selection.push("phone");
        }
        if (jQuery('#country').prop("checked") == true) {
            selection.push("country");
        }
        if (jQuery('#id').prop("checked") == true) {
            selection.push("id");
        }
        if (jQuery('#city').prop("checked") == true) {
            selection.push("city");
        }
        
        
        var result = selection.join(', ');
        jQuery.post(url, {
                selection: result
            },
            function(data, status) {
                // console.log(data);
            });
        // var searchValue = mQuery('#list-search').typeahead('val');
        var searchValue = jQuery('#list-search')[0].value;
        var string = '';
        if (searchValue.toLowerCase().indexOf('!' + string) == 0) {
            searchValue = searchValue.replace('!' + string, string);
        } else if (searchValue.toLowerCase().indexOf(string) == -1) {
            if (searchValue) {
                searchValue = searchValue + ' ' + string;
            } else {
                searchValue = string;
            }
        } else {
            searchValue = mQuery.trim(searchValue.replace(string, ''));
        }
        searchValue = searchValue.replace("  ", " ");
        Mautic.setSearchFilter(null, 'list-search', searchValue);
    }
    jQuery('.box-layout,.panel-body,.page-list,.page-header').click(function() {
        checkboxes.style.display = "none";
    });
</script>
<!--ended by Nirmal for company columns-->

