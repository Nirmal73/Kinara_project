<?php

echo $view['form']->form($quickForm);
