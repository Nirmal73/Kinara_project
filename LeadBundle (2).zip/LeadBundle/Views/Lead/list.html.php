<?php

/*
 * @copyright   2014 Mautic Contributors. All rights reserved
 * @author      Mautic
 *
 * @link        http://mautic.org
 *
 * @license     GNU/GPLv3 http://www.gnu.org/licenses/gpl-3.0.html
 */
 
 
//  Added by Nirmal for select column

 /** @var \Symfony\Bundle\FrameworkBundle\Templating\GlobalVariables $app */
include('././app/config/local.php');
// Get the user Id of the user who logged in
$user_id = $app->getUser()->getId();
$url = $parameters['site_url'].'/media/addons/contact_field.php/?id='.$user_id;
$cURLConnection = curl_init();
curl_setopt($cURLConnection , CURLOPT_URL,$url);
curl_setopt($cURLConnection , CURLOPT_RETURNTRANSFER, true);
$selectionList = curl_exec($cURLConnection); // getting selection list from database
curl_close($cURLConnection);
$tc = 0;
$ts = "table";
if (strpos($selectionList, 'country') !== false) {
    $tc = $tc + 1;
}
if (strpos($selectionList, 'mobile') !== false) {
    $tc = $tc + 1;
}
if (strpos($selectionList, 'phone') !== false) {
    $tc = $tc + 1;
}
if (strpos($selectionList, 'points') !== false) {
    $tc = $tc + 1;
}
if (strpos($selectionList, 'position') !== false) {
    $tc = $tc + 1;
}
if (strpos($selectionList, 'id') !== false) {
    $tc = $tc + 1;
}
if (strpos($selectionList, 'lastactive') !== false) {
    $tc = $tc + 1;
}
if($tc > 1){
    $ts ="block";
}

// Ended by Nirmal for select column
 
if ('index' == $tmpl) {
    $view->extend('MauticLeadBundle:Lead:index.html.php');
}

$customButtons = [];
if ($permissions['lead:leads:editown'] || $permissions['lead:leads:editother']) {
    $customButtons = [
        [
            'attr' => [
                'class'       => 'btn btn-default btn-sm btn-nospin',
                'data-toggle' => 'ajaxmodal',
                'data-target' => '#MauticSharedModal',
                'href'        => $view['router']->path('mautic_segment_batch_contact_view'),
                'data-header' => $view['translator']->trans('mautic.lead.batch.lists'),
            ],
            'btnText'   => $view['translator']->trans('mautic.lead.batch.lists'),
            'iconClass' => 'fa fa-pie-chart',
        ],
        [
            'attr' => [
                'class'       => 'btn btn-default btn-sm btn-nospin',
                'data-toggle' => 'ajaxmodal',
                'data-target' => '#MauticSharedModal',
                'href'        => $view['router']->path('mautic_contact_action', ['objectAction' => 'batchStages']),
                'data-header' => $view['translator']->trans('mautic.lead.batch.stages'),
            ],
            'btnText'   => $view['translator']->trans('mautic.lead.batch.stages'),
            'iconClass' => 'fa fa-tachometer',
        ],
        [
            'attr' => [
                'class'       => 'btn btn-default btn-sm btn-nospin',
                'data-toggle' => 'ajaxmodal',
                'data-target' => '#MauticSharedModal',
                'href'        => $view['router']->path('mautic_contact_action', ['objectAction' => 'batchCampaigns']),
                'data-header' => $view['translator']->trans('mautic.lead.batch.campaigns'),
            ],
            'btnText'   => $view['translator']->trans('mautic.lead.batch.campaigns'),
            'iconClass' => 'fa fa-clock-o',
        ],
        [
            'attr' => [
                'class'       => 'btn btn-default btn-sm btn-nospin',
                'data-toggle' => 'ajaxmodal',
                'data-target' => '#MauticSharedModal',
                'href'        => $view['router']->path('mautic_contact_action', ['objectAction' => 'batchOwners']),
                'data-header' => $view['translator']->trans('mautic.lead.batch.owner'),
            ],
            'btnText'   => $view['translator']->trans('mautic.lead.batch.owner'),
            'iconClass' => 'fa fa-user',
        ],
        [
            'attr' => [
                'class'       => 'btn btn-default btn-sm btn-nospin',
                'data-toggle' => 'ajaxmodal',
                'data-target' => '#MauticSharedModal',
                'href'        => $view['router']->path('mautic_contact_action', ['objectAction' => 'batchDnc']),
                'data-header' => $view['translator']->trans('mautic.lead.batch.dnc'),
            ],
            'btnText'   => $view['translator']->trans('mautic.lead.batch.dnc'),
            'iconClass' => 'fa fa-ban text-danger',
        ],
    ];
}
?>

<?php if (count($items)): ?>
<div class="table-responsive" style="overflow-x:auto;">
    <table class="table table-hover table-striped table-bordered" id="leadTable">
        <thead>
            <tr>
                <?php
                echo $view->render('MauticCoreBundle:Helper:tableheader.html.php', [
                    'checkall'        => 'true',
                    'target'          => '#leadTable',
                    'templateButtons' => [
                        'delete' => $permissions['lead:leads:deleteown'] || $permissions['lead:leads:deleteother'],
                    ],
                    'customButtons' => $customButtons,
                    'langVar'       => 'lead.lead',
                    'routeBase'     => 'contact',
                    'tooltip'       => $view['translator']->trans('mautic.lead.list.checkall.help'),
                ]);
                
                echo $view->render('MauticCoreBundle:Helper:tableheader.html.php', [
                    'sessionVar' => 'lead',
                    'orderBy'    => 'l.firstname, l.company, l.email',
                    'text'       => 'mautic.core.firstname',
                    'class'      => 'col-lead-firstname',
                ]);
                echo $view->render('MauticCoreBundle:Helper:tableheader.html.php', [
                    'sessionVar' => 'lead',
                    'orderBy'    => 'l.lastname, l.company, l.email',
                    'text'       => 'mautic.core.lastname',
                    'class'      => 'col-lead-lastname visible-md visible-lg',
                ]);
                echo $view->render('MauticCoreBundle:Helper:tableheader.html.php', [
                    'sessionVar' => 'lead',
                    'orderBy'    => 'l.company',
                    'text'       => 'mautic.core.company',
                    'class'      => 'col-lead-company visible-md visible-lg',
                ]);
                echo $view->render('MauticCoreBundle:Helper:tableheader.html.php', [
                    'sessionVar' => 'lead',
                    'orderBy'    => 'l.email',
                    'text'       => 'mautic.core.type.email',
                    'class'      => 'col-lead-email visible-md visible-lg',
                ]);
                echo $view->render('MauticCoreBundle:Helper:tableheader.html.php', [
                    'sessionVar' => 'lead',
                    'orderBy'    => 'l.city',
                    'text'       => 'mautic.lead.lead.thead.city',
                    'class'      => 'col-lead-city visible-md visible-lg',
                ]);
                if (strpos($selectionList, 'stage') !== false) {
                    echo $view->render('MauticCoreBundle:Helper:tableheader.html.php', [
                        'sessionVar' => 'lead',
                        'orderBy'    => 'l.stage_id',
                        'text'       => 'mautic.stage.stage',
                        'class' => 'col-lead-stageid visible-md visible-lg',
                    ]);
                }
                if (strpos($selectionList, 'country') !== false) {
                    echo $view->render('MauticCoreBundle:Helper:tableheader.html.php', [
                        'sessionVar' => 'lead',
                        'orderBy'    => 'l.country',
                        'text'       => 'mautic.lead.lead.thead.country',
                        'class'      => 'col-lead-country visible-md visible-lg',
                    ]);
                }
                if (strpos($selectionList, 'mobile') !== false) {
                    echo $view->render('MauticCoreBundle:Helper:tableheader.html.php', [
                        'sessionVar' => 'lead',
                        'orderBy'    => 'l.mobile',
                        'text'       => 'Mobile',
                        'class'      => 'col-lead-mobile visible-md visible-lg',
                    ]);
                }
                if (strpos($selectionList, 'phone') !== false) {
                    echo $view->render('MauticCoreBundle:Helper:tableheader.html.php', [
                        'sessionVar' => 'lead',
                        'orderBy'    => 'l.phone',
                        'text'       => 'mautic.core.type.tel',
                        'class'      => 'col-lead-phone visible-md visible-lg',
                    ]);
                }
                if (strpos($selectionList, 'points') !== false) {
                    echo $view->render('MauticCoreBundle:Helper:tableheader.html.php', [
                        'sessionVar' => 'lead',
                        'orderBy'    => 'l.points',
                        'text'       => 'mautic.lead.points',
                        'class'      => 'visible-md visible-lg col-lead-points',
                    ]);
                }
                if (strpos($selectionList, 'position') !== false) {
                    echo $view->render('MauticCoreBundle:Helper:tableheader.html.php', [
                        'sessionVar' => 'lead',
                        'orderBy'    => 'l.position',
                        'text'       => 'mautic.core.position',
                        'class'      => 'col-lead-position visible-md visible-lg',
                    ]);
                }
                if (strpos($selectionList, 'id') !== false) {
                    echo $view->render('MauticCoreBundle:Helper:tableheader.html.php', [
                        'sessionVar' => 'lead',
                        'orderBy'    => 'l.id',
                        'text'       => 'mautic.core.id',
                        'class' => 'col-lead-id',
                ]);
                }
                if (strpos($selectionList, 'lastactive') !== false) {
                        echo $view->render('MauticCoreBundle:Helper:tableheader.html.php', [
                            'sessionVar' => 'lead',
                            'orderBy'    => 'l.last_active',
                            'text'       => 'mautic.lead.lastactive',
                            'class'      => 'col-lead-lastactive',
                ]);
                }


                // $columsAliases = array_flip($columns);
                // foreach ($columns as $column=>$label) {
                //     $template = 'MauticLeadBundle:Lead\header:'.$column.'.html.php';
                //     if (!$view->exists($template)) {
                //         $template = 'MauticLeadBundle:Lead\header:default.html.php';
                //     }
                //     echo $view->render(
                //         $template,
                //         [
                //             'label'  => $label,
                //             'column' => $column,
                //             'class'  => array_search($column, $columsAliases) > 1 ? 'hidden-xs' : '',
                //         ]
                //     );
                // }
                ?>
            </tr>
        </thead>
        <tbody>
        <?php echo $view->render('MauticLeadBundle:Lead:list_rows.html.php', [
            'items'         => $items,
            'columns'       => $columns,
            'security'      => $security,
            'currentList'   => $currentList,
            'permissions'   => $permissions,
            'noContactList' => $noContactList,
        ]); ?>
        </tbody>
    </table>
</div>
<div class="panel-footer">
    <?php echo $view->render('MauticCoreBundle:Helper:pagination.html.php', [
        'totalItems' => $totalItems,
        'page'       => $page,
        'limit'      => $limit,
        'menuLinkId' => 'mautic_contact_index',
        'baseUrl'    => $view['router']->path('mautic_contact_index'),
        'tmpl'       => $indexMode, 
        'sessionVar' => 'lead',
    ]); ?>
</div>
<?php else: ?>
<script> jQuery('#ms').css('opacity',0); </script>
<?php echo $view->render('MauticCoreBundle:Helper:noresults.html.php'); ?>
<?php endif; ?>
