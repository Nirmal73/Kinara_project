<?php

/*
 * @copyright   2014 Mautic Contributors. All rights reserved
 * @author      Mautic
 *
 * @link        http://mautic.org
 *
 * @license     GNU/GPLv3 http://www.gnu.org/licenses/gpl-3.0.html
 */
 
/** @var \Symfony\Bundle\FrameworkBundle\Templating\GlobalVariables $app */
include('././app/config/local.php');
include('../../Assets/css/lead.css');
// Get the user Id of the user who logged in
$user_id = $app->getUser()->getId();
$url = $parameters['site_url'].'/media/addons/contact_field.php/?id='.$user_id;
$con = curl_init();
curl_setopt($con, CURLOPT_URL, $url);
curl_setopt($con, CURLOPT_RETURNTRANSFER, true);
$selectionlist = curl_exec($con);
$cURLConnection = curl_init();
curl_setopt($cURLConnection , CURLOPT_URL,$url);
curl_setopt($cURLConnection , CURLOPT_RETURNTRANSFER, true);
$selectionlist = curl_exec($cURLConnection); // getting selection list from database
$ce = curl_error($cURLConnection);
curl_close($cURLConnection);

 
 
$view->extend('MauticCoreBundle:Default:content.html.php');
$view['slots']->set('mauticContent', 'lead');
$view['slots']->set('headerTitle', $view['translator']->trans('mautic.lead.leads'));

$pageButtons = [];
if ($permissions['lead:leads:create']) {
    $pageButtons[] = [
        'attr' => [
            'class'       => 'btn btn-default btn-nospin quickadd',
            'data-toggle' => 'ajaxmodal',
            'data-target' => '#MauticSharedModal',
            'href'        => $view['router']->path('mautic_contact_action', ['objectAction' => 'quickAdd']),
            'data-header' => $view['translator']->trans('mautic.lead.lead.menu.quickadd'),
        ],
        'iconClass' => 'fa fa-bolt',
        'btnText'   => 'mautic.lead.lead.menu.quickadd',
        'primary'   => true,
    ];

    if ($permissions['lead:imports:create']) {
        $pageButtons[] = [
            'attr' => [
                'href' => $view['router']->path('mautic_import_action', ['object' => 'contacts', 'objectAction' => 'new']),
            ],
            'iconClass' => 'fa fa-upload',
            'btnText'   => 'mautic.lead.lead.import',
        ];
    }

    if ($permissions['lead:imports:view']) {
        $pageButtons[] = [
            'attr' => [
                'href' => $view['router']->path('mautic_import_index', ['object' => 'contacts']),
            ],
            'iconClass' => 'fa fa-history',
            'btnText'   => 'mautic.lead.lead.import.index',
        ];
    }
}

// Only show toggle buttons for accessibility
$extraHtml = <<<button
<div class="btn-group ml-5 sr-only ">
    <span data-toggle="tooltip" title="{$view['translator']->trans(
    'mautic.lead.tooltip.list'
)}" data-placement="left"><a id="table-view" href="{$view['router']->path('mautic_contact_index', ['page' => $page, 'view' => 'list'])}" data-toggle="ajax" class="btn btn-default"><i class="fa fa-fw fa-table"></i></span></a>
    <span data-toggle="tooltip" title="{$view['translator']->trans(
    'mautic.lead.tooltip.grid'
)}" data-placement="left"><a id="card-view" href="{$view['router']->path('mautic_contact_index', ['page' => $page, 'view' => 'grid'])}" data-toggle="ajax" class="btn btn-default"><i class="fa fa-fw fa-th-large"></i></span></a>
</div>
button;

$view['slots']->set(
    'actions',
    $view->render(
        'MauticCoreBundle:Helper:page_actions.html.php',
        [
            'templateButtons' => [
                'new' => $permissions['lead:leads:create'],
            ],
            'routeBase'     => 'contact',
            'langVar'       => 'lead.lead',
            'customButtons' => $pageButtons,
            'extraHtml'     => $extraHtml,
        ]
    )
);

$toolbarButtons = [
    [
        'attr' => [
            'class'       => 'hidden-xs btn btn-default btn-sm btn-nospin',
            'href'        => 'javascript: void(0)',
            'onclick'     => 'Mautic.toggleLiveLeadListUpdate();',
            'id'          => 'liveModeButton',
            'data-toggle' => false,
            'data-max-id' => $maxLeadId,
        ],
        'tooltip'   => $view['translator']->trans('mautic.lead.lead.live_update'),
        'iconClass' => 'fa fa-bolt',
    ],
];

if ($indexMode == 'list')  {
    $toolbarButtons[] = [
        'attr' => [
            'class'          => 'hidden-xs btn btn-default btn-sm btn-nospin'.(($anonymousShowing) ? ' btn-primary' : ''),
            'href'           => 'javascript: void(0)',
            'onclick'        => 'Mautic.toggleAnonymousLeads();',
            'id'             => 'anonymousLeadButton',
            'data-anonymous' => $view['translator']->trans('mautic.lead.lead.searchcommand.isanonymous'),
        ],
        'tooltip'   => $view['translator']->trans('mautic.lead.lead.anonymous_leads'),
        'iconClass' => 'fa fa-user-secret',
    ];
}
?>

<div class="panel panel-default bdr-t-wdh-0 mb-0">
    <div id="ms" class="multiselect visible-md visible-lg" style="float:right; padding-bottom:1%;">
        <div class="selectBox" onclick="showCheckboxes()" >
            <select>
                 <div class="overSelect"></div>    
                <option>Select Columns</option>
            </select>
            <div class="overSelect"></div>
        </div>
        <div id="checkboxes" >
            <label for="stage">
                <input type="checkbox" id="stage" value="stage" onchange="check()"> Stage
            </label>
            <label for="country">
                <input type="checkbox" id="country" value="country" onchange="check()"> Country</label>
            <label for="mobile">
                <input type="checkbox" id="mobile" value="mobile" onchange="check()"> Mobile</label>
            <label for="phone">
                <input type="checkbox" id="phone" value="phone" onchange="check()"> Phone</label>
            <label for="points">
                <input type="checkbox" id="points" value="points" onchange="check()"> Points</label>
            <label for="position">
                <input type="checkbox" id="position" value="position" onchange="check()"> Position</label>
            <label for="id">
                <input type="checkbox" id="id" value="id" onchange="check()"> Id</label>
            <label for="lastactive">
                <input type="checkbox" id="lastactive" value="lastactive" onchange="check()"> Lastactive</label>
            <span style="color: #2196F3; padding-top: 3px; padding-bottom: 3px;font-size: 9.9px;background-color: #f9f9f9;">(To add custom fields contact Support)</span>
        </div>
    </div>
    <?php echo $view->render(
        'MauticCoreBundle:Helper:list_toolbar.html.php',
        [
            'searchValue'   => $searchValue,
            'searchHelp'    => 'mautic.lead.lead.help.searchcommands',
            'action'        => $currentRoute,
            'customButtons' => $toolbarButtons,
            'contactfilters'=>true,
        ]
    ); ?>
    <div class="page-list">
        <?php $view['slots']->output('_content'); ?>
    </div>
</div>
<script>
url = '<?php echo $url ?>';
jQuery.get(url,{ 
    },
    function(data, status){
        if(data.length > 0){
            var res = data.split(',');
            jQuery.each(res,function(key,value){
                jQuery('#'+value.trim()).prop("checked","true");
            });
        }
    });
var expanded = false;
function showCheckboxes() {
var checkboxes = document.getElementById("checkboxes");
if (!expanded) {
    checkboxes.style.display = "block";
    expanded = true;
} else {
    checkboxes.style.display = "none";
    expanded = false;
}
}
function check(){
    selection =[];
    if(jQuery('#stage').prop("checked") == true){
        selection.push("stage");
    }
    if(jQuery('#phone').prop("checked") == true){
        selection.push("phone");
    }
    if(jQuery('#points').prop("checked") == true){
        selection.push("points");
    }
    if(jQuery('#country').prop("checked") == true){
        selection.push("country");
    }
    if(jQuery('#position').prop("checked") == true){
        selection.push("position");
    }
    if(jQuery('#mobile').prop("checked") == true){
        selection.push("mobile");
    }
    if(jQuery('#id').prop("checked") == true){
        selection.push("id");
    }
    if(jQuery('#lastactive').prop("checked") == true){
        selection.push("lastactive");
    }
    var result = selection.join(', ');
   jQuery.post(url,{
            selection: result
    },
    function(data, status){
        //console.log(data);
    });
    var searchValue = mQuery('#list-search').typeahead('val');
    var string      = '';
    if (searchValue.toLowerCase().indexOf('!' + string) == 0) {
        searchValue = searchValue.replace('!' + string, string);
    } else if (searchValue.toLowerCase().indexOf(string) == -1) {
        if (searchValue) {
            searchValue = searchValue + ' ' + string;
        } else {
            searchValue = string;
        }
    } else {
        searchValue = mQuery.trim(searchValue.replace(string, ''));
    }
    searchValue = searchValue.replace("  ", " ");
    Mautic.setSearchFilter(null, 'list-search', searchValue);
    }
    jQuery('.page-header,.box-layout,.page-list,.page-header').click(function(){
        checkboxes.style.display = "none";
    });
</script>
<script>
    function batchUpdate(){
        let totaltd = jQuery('#leadTable')[0]['rows'].length;
        let ids =[]
        for(let i= 1;i<totaltd;i++){
            if(jQuery('#leadTable')[0]['rows'][i].className ==='active'){
                ids.push($('#leadTable')[0]['rows'][i].cells[1].children[0].href.match(/\d+/g)[0]);
            }
        }
        let url = 'batchupdate?id='+ids.toString();
        Mautic.loadAjaxModal('#MauticSharedModal', url, 'get', 'Batch Update');
    }
</script>
