<?php

/*
 * @copyright   2014 Mautic Contributors. All rights reserved
 * @author      Mautic
 *
 * @link        http://mautic.org
 *
 * @license     GNU/GPLv3 http://www.gnu.org/licenses/gpl-3.0.html
 */
 /** @var \Symfony\Bundle\FrameworkBundle\Templating\GlobalVariables $app */
include('././app/config/local.php');
// Get the user Id of the user who logged in
$user_id = $app->getUser()->getId();
$url = $parameters['site_url'].'/media/addons/contact_field.php/?id='.$user_id;
$cURLConnection = curl_init();
curl_setopt($cURLConnection , CURLOPT_URL,$url);
curl_setopt($cURLConnection , CURLOPT_RETURNTRANSFER, true);
$selectionList = curl_exec($cURLConnection); // getting selection list from database
curl_close($cURLConnection);

?>

        <?php foreach ($items as $item): ?>
            <?php /** @var \Mautic\LeadBundle\Entity\Lead $item */ ?>
            <?php $fields = $item->getFields(); ?>
            <tr<?php if (!empty($highlight)): echo ' class="warning"'; endif; ?>>
                <td>
                    <?php
                    $hasEditAccess = $security->hasEntityAccess(
                        $permissions['lead:leads:editown'],
                        $permissions['lead:leads:editother'],
                        $item->getPermissionUser()
                    );

                    $custom = [];

                    if ($hasEditAccess && !empty($currentList)) {
                        //this lead was manually added to a list so give an option to remove them
                        $custom[] = [
                            'attr' => [
                                'href' => $view['router']->path('mautic_segment_action', [
                                    'objectAction' => 'removeLead',
                                    'objectId'     => $currentList['id'],
                                    'leadId'       => $item->getId(),
                                ]),
                                'data-toggle' => 'ajax',
                                'data-method' => 'POST',
                            ],
                            'btnText'   => 'mautic.lead.lead.remove.fromlist',
                            'iconClass' => 'fa fa-remove',
                        ];
                    }

                    if (!empty($fields['core']['email']['value'])) {
                        $custom[] = [
                            'attr' => [
                                'data-toggle' => 'ajaxmodal',
                                'data-target' => '#MauticSharedModal',
                                'data-header' => $view['translator']->trans('mautic.lead.email.send_email.header', ['%email%' => $fields['core']['email']['value']]),
                                'href'        => $view['router']->path('mautic_contact_action', ['objectId' => $item->getId(), 'objectAction' => 'email', 'list' => 1]),
                            ],
                            'btnText'   => 'mautic.lead.email.send_email',
                            'iconClass' => 'fa fa-send',
                        ];
                    }

                    echo $view->render('MauticCoreBundle:Helper:list_actions.html.php', [
                        'item'            => $item,
                        'templateButtons' => [
                            'edit'   => $hasEditAccess,
                            'delete' => $security->hasEntityAccess($permissions['lead:leads:deleteown'], $permissions['lead:leads:deleteother'], $item->getPermissionUser()),
                        ],
                        'routeBase'     => 'contact',
                        'langVar'       => 'lead.lead',
                        'customButtons' => $custom,
                    ]);
                    ?>
                </td>
                 <td>
                    <a href="<?php echo $view['router']->path('mautic_contact_action', ['objectAction' => 'view', 'objectId' => $item->getId()]); ?>" data-toggle="ajax">
                        <?php if (in_array($item->getId(), array_keys($noContactList)))  : ?>
                            <div class="pull-right label label-danger"><i class="fa fa-ban"> </i></div>
                        <?php endif; ?>
                        <!-- <div><?php echo ($item->isAnonymous()) ? $view['translator']->trans($item->getPrimaryIdentifier()) : $item->getPrimaryIdentifier(); ?></div>
                        <div class="small"><?php echo $item->getSecondaryIdentifier(); ?></div> -->
                        <div> <?php if($item->isAnonymous()){ echo $item->isAnonymous();}else { echo $item->getFirstname();} ?></div>
                    </a>
                </td>
                <td class="visible-md visible-lg"> <?php echo $item->getLastName(); ?></td>
                <td class="visible-md visible-lg"> <?php echo $item->getCompany(); ?></td>
                <td class="visible-md visible-lg"><?php echo $fields['core']['email']['value']; ?></td>
                <td class="visible-md visible-lg"> <?php echo $item->getCity(); ?></td>
                <?php if (strpos($selectionList, 'stage') !== false) {?>
                <td class="visible-md visible-lg">
                    <?php
                    $s = $item->getStage();
                    if($s){
                        echo $item->getStage()->getName();
                    }
                ?>
                </td>
                <?php } ?>
                
                <?php if (strpos($selectionList, 'country') !== false) {?>
                    <td class="visible-md visible-lg"><?php echo $item->getCountry(); ?></td>
                <?php } ?>
                <?php if (strpos($selectionList, 'mobile') !== false) {?>
                    <td class="visible-md visible-lg"><?php echo $item->getMobile(); ?></td>
                <?php } ?>
                <?php if (strpos($selectionList, 'phone') !== false) {?>
                    <td class="visible-md visible-lg"><?php echo $item->getPhone(); ?></td>
                <?php } ?>
                <?php if (strpos($selectionList, 'points') !== false) {?>
                    <td class="visible-md visible-lg text-center">
                        <?php
                        $color = $item->getColor();
                        $style = !empty($color) ? ' style="background-color: '.$color.';"' : '';
                        ?>
                        <span class="label label-default"<?php echo $style; ?>><?php echo $item->getPoints(); ?></span>
                    </td>
                <?php } ?>
                <?php if (strpos($selectionList, 'position') !== false) {?>
                    <td class="visible-md visible-lg"><?php echo $item->getPosition(); ?></td>
                <?php } ?>
                <?php if (strpos($selectionList, 'id') !== false) {?>
                    <td><?php echo $item->getId(); ?></td><?php } ?>
                <?php if (strpos($selectionList, 'lastactive') !== false) {?>
                <td class="visible-md visible-lg">
                    <abbr title="<?php echo $view['date']->toFull($item->getLastActive()); ?>">
                    <?php echo $view['date']->toText($item->getLastActive()); ?>
                    </abbr>
                </td><?php } ?>
            </tr>
            
        <?php endforeach; ?>
