<?php

foreach ($form as $f) {
    echo $view['form']->row($f);
}
