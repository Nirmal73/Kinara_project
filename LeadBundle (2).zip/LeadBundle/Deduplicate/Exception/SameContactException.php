<?php

namespace Mautic\LeadBundle\Deduplicate\Exception;

class SameContactException extends \Exception
{
}
