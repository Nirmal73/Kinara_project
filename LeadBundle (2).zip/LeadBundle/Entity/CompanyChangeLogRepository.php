<?php

namespace Mautic\LeadBundle\Entity;

use Mautic\CoreBundle\Entity\CommonRepository;

/**
 * Class CompanyChangeLogRepository.
 */
class CompanyChangeLogRepository extends CommonRepository
{
}
