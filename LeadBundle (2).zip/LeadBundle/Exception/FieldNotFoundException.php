<?php

namespace Mautic\LeadBundle\Exception;

class FieldNotFoundException extends \Exception
{
}
