<?php

namespace Mautic\LeadBundle\Exception;

class ImportFailedException extends \Exception
{
}
