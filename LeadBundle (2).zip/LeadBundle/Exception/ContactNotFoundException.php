<?php

namespace Mautic\LeadBundle\Exception;

class ContactNotFoundException extends \Exception
{
}
