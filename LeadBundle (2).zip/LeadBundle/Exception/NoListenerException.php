<?php

declare(strict_types=1);

namespace Mautic\LeadBundle\Exception;

class NoListenerException extends \Exception
{
}
