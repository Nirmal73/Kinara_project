<?php

namespace Mautic\LeadBundle\Exception;

class UniqueFieldNotFoundException extends \Exception
{
}
