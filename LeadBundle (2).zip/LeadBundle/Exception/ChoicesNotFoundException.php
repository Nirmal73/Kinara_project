<?php

declare(strict_types=1);

namespace Mautic\LeadBundle\Exception;

class ChoicesNotFoundException extends \Exception
{
}
