<?php

namespace Mautic\LeadBundle\Exception;

class ImportDelayedException extends \Exception
{
}
