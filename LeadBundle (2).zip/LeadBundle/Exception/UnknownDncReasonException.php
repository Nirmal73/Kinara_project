<?php

namespace Mautic\LeadBundle\Exception;

class UnknownDncReasonException extends \Exception
{
}
