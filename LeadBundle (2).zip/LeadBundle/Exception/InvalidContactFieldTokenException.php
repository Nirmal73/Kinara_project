<?php

declare(strict_types=1);

namespace Mautic\LeadBundle\Exception;

use Mautic\CoreBundle\Exception\InvalidValueException;

class InvalidContactFieldTokenException extends InvalidValueException
{
}
